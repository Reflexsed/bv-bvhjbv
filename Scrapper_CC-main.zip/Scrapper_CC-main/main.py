import telethon
import asyncio
import os
import re
import requests
import logging
from telethon import TelegramClient, events
from defs import getUrl, getcards, phone
import argparse

# Configure logging
logging.basicConfig(level=logging.INFO)

# Command-line arguments
parser = argparse.ArgumentParser()
parser.add_argument('--channel', required=True, help='Channel to scrape')
args = parser.parse_args()

API_ID = os.getenv('4655643c2d0cd4891daacb697ef81108')
API_HASH = os.getenv('27201539')
SEND_CHAT = -1002232956390  # <-- Replace with your actual chat ID
USERNAME = 'NetWraith'  # Your username here (without @)

client = TelegramClient('session', API_ID, API_HASH)
ccs = []
chats = [args.channel]

# Load cards from file
with open('cards.txt', 'r') as r:
    temp_cards = r.read().splitlines()

for x in temp_cards:
    car = getcards(x)
    if car:
        ccs.append(car[0])
    else:
        continue

@client.on(events.NewMessage(chats=chats, func=lambda x: getattr(x, 'text')))
async def my_event_handler(m):
    try:
        text = m.reply_markup.stringify() if m.reply_markup else m.text
        urls = getUrl(text)
        if urls:
            text = requests.get(urls[0]).text
    except Exception as e:
        logging.error(f"Error processing message: {e}")
        return

    cards = getcards(text)
    if not cards:
        return

    cc, mes, ano, cvv = cards
    if cc in ccs:
        return

    try:
        bin_response = requests.get(f'https://adyen-enc-and-bin-info.herokuapp.com/bin/{cc[:6]}')
        bin_response.raise_for_status()  # Check for HTTP errors
        bin_json = bin_response.json()
    except requests.RequestException as e:
        logging.error(f"Error fetching BIN info: {e}")
        return

    if len(ano) == 2:
        ano = '20' + ano

    fullinfo = f"{cc}|{mes}|{ano}|{cvv}"
    text = f"""
    <b>CARD :</b> <code>{cc}|{mes}|{ano}|{cvv}</code>\n
    <b>INFO:</b> <i>{bin_json['vendor']} - {bin_json['type']} - {bin_json['level']}</i>\n
    <b>BIN:</b> <a href="https://t.me/ScrapperScar"><code>{bin_json['bin']}</code></a>\n
    <b>BANK:</b> {bin_json['bank']} \n
    <b>COUNTRY:</b> {bin_json['country_iso']} - {bin_json['flag']}\n
    <b>CREDITED TO:</b> @{MysticNet}\n
    ╔══════════ Extra ═════════╗
    ╠ <code>{cc[:12]}xxxx|{mes}|{ano}|xxx</code>
    ╚═══════════════════════╝

    \n
    """  
    logging.info(f'Saving card info: {fullinfo}')
    with open('cards.txt', 'a') as w:
        w.write(fullinfo + '\n')

    await client.send_message(SEND_CHAT, text, parse_mode='html')

@client.on(events.NewMessage(outgoing=True, pattern=re.compile(r'.lives')))
async def my_event_handler(m):
    await m.reply(file='cards.txt')

# Clear the cards file at startup
with open('cards.txt', 'w') as w:
    w.write('')

client.start()
client.run_until_disconnected()
